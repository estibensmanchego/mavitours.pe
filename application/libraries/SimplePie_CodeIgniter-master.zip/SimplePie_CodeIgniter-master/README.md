SimplePie_CodeIgniter
=====================

SimplePie+CodeIgniter is an integration of the latest SimplePie RSS parser with CodeIgniter.
